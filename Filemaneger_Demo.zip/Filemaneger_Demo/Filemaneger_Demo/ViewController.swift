//
//  ViewController.swift
//  Filemaneger_Demo
//
//  Created by SOTSYS032 on 06/06/18.
//  Copyright © 2018 SpaceoDigicom. All rights reserved.
//

import UIKit
import QuickLook


class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,QLPreviewControllerDelegate,QLPreviewControllerDataSource {

    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var tblViewData: UITableView!
    
    var arrDouments = Array<String>()
    var selectedItems = Array<String>()
    var quickItem : URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(paths!)
        if currPath == paths {
            arrDouments = dcData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
       
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func getLocalFiles() {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let cacheDirectory = paths[0]
        print(cacheDirectory)
        var error: Error?
        arrDouments = try! FileManager.default.contentsOfDirectory(atPath: cacheDirectory)
        if error != nil {
            if let anError = error {
                print("Error: \(anError)")
            }
        }
    }
    

     //MARK:- Table View Delegates & DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrDouments.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! FolderDataCell
        let fileName = arrDouments[indexPath.row]
        cell.lblFileName.text = fileName
        if (fileName.components(separatedBy: ".").count == 2){
            cell.imgviewFile.image = UIImage(named: fileName.components(separatedBy: ".").last!)
        }else{
            cell.imgviewFile.image = #imageLiteral(resourceName: "Folders")
        }
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
          let fileType = arrDouments[indexPath.row]
        if (fileType.components(separatedBy: ".").count == 2) {
           quickItem =  currPath?.appendingPathComponent(fileType)
            print(quickItem!)
            if tblViewData.isEditing == false{
                  openQlPreview()
            }
            return
        }
        if tblViewData.isEditing == true{
            let filePath = arrDouments[(indexPath as NSIndexPath).row]
             if let index = selectedItems.index(of: filePath) , selectedItems.contains(filePath) {
                selectedItems.remove(at: index)
            }else{
                selectedItems.append(arrDouments[indexPath.row])
            }
        }
        else{
            let nextVC = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
            currPath?.appendPathComponent(fileType)
            nextVC.arrDouments = loadImagesFromAlbum(folderName: fileType)
            self.navigationController?.pushViewController(nextVC, animated: true)
            lblTitle.text = fileType
        }
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return UITableViewCellEditingStyle(rawValue: 3)!
    }
    
    
    
    func editData(){
        if tblViewData.isEditing == false{
            tblViewData.setEditing(true, animated: true)
        }
        else {
            tblViewData.setEditing(false, animated: false)
        }
    }
    
    //MARK:- Open Doc
    
    func openQlPreview() {
        let previoew = QLPreviewController.init()
        previoew.dataSource = self
        previoew.delegate = self
        self.present(previoew, animated: true, completion: nil)
    }
    
    //MARK:- QuickLook Delegate
    
    func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
        return 1
    }
    
    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        //  pass your document url here
        let fileURL = quickItem
        print(fileURL!)
        return fileURL as! QLPreviewItem
    }
    
    func previewController(_ controller: QLPreviewController, shouldOpen url: URL, for item: QLPreviewItem) -> Bool {
        return true
    }
    
    
    
    //MARK:- Button Event
    
    @IBAction func btnTapBack(_ sender: UIButton) {
        
        if currPath == paths {
            return
        }else{
            let updatedURL = currPath?.deletingLastPathComponent()
            currPath = updatedURL
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func btnTapNewFolder(_ sender: UIButton) {
        let alertController = UIAlertController(title: "Add New Folder", message: "", preferredStyle: UIAlertControllerStyle.alert)
        alertController.addTextField { (textField : UITextField!) in
            textField.placeholder = "Enter Folder Name"
        }
        let saveAction = UIAlertAction(title: "Save", style: .default) { (alert) in
             let firstTextField = alertController.textFields![0] as UITextField
            createFolder(withName: firstTextField.text!)
            self.arrDouments = dcData()
            self.tblViewData.reloadData()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
         self.present(alertController, animated: true, completion: nil)
    }
 
    @IBAction func btnTapEdit(_ sender: UIButton) {
        editData()
    }
    
    
    @IBAction func btnTapDelete(_ sender: UIButton) {
        if selectedItems.count != 0{
            for i in selectedItems{
                delDirectory(deleteFolder: i)
            }
            self.arrDouments = dcData()
            self.tblViewData.reloadData()
            tblViewData.setEditing(false, animated: false)
        }
    }
    
    
}

