//
//  Helper.swift
//  Filemaneger_Demo
//
//  Created by SOTSYS032 on 06/06/18.
//  Copyright © 2018 SpaceoDigicom. All rights reserved.
//

import UIKit


let paths = FileManager.default.urls(for: FileManager.SearchPathDirectory.documentDirectory, in: FileManager.SearchPathDomainMask.userDomainMask).first
var currPath = paths

//MARK :- New Directory

func createFolder(withName name : String) {
    let filemgr = FileManager.default
    let newDir = currPath?.appendingPathComponent(name).path
    do {
        try filemgr.createDirectory(atPath: newDir!,
                                    withIntermediateDirectories: true, attributes: nil)
    } catch let error as NSError {
        print("Error: \(error.localizedDescription)")
    }
}



//MARK :- delete Directory

func delDirectory(deleteFolder name : String) {
    let filemgr = FileManager.default
    let newDir = currPath?.appendingPathComponent(name).path
    do {
        try filemgr.removeItem(atPath: newDir!)
    } catch let error as NSError {
        print("Error: \(error.localizedDescription)")
    }
}


//MARK:-  Multiple folder

func loadImagesFromAlbum(folderName:String) -> [String]{
    let pathsData = FileManager.default.urls(for: FileManager.SearchPathDirectory.documentDirectory, in: FileManager.SearchPathDomainMask.userDomainMask)
    var theItems = [String]()
    if pathsData.first != nil {
        do {
            theItems = try FileManager.default.contentsOfDirectory(atPath: (currPath?.path)!)
            return theItems
        } catch let error as NSError {
            print(error.localizedDescription)
            return theItems
        }
    }
    return theItems
}

func dcData() -> [String]{
     let pathsData = FileManager.default.urls(for: FileManager.SearchPathDirectory.documentDirectory, in: FileManager.SearchPathDomainMask.userDomainMask)
    var theItems = [String]()
   if pathsData.first != nil {
        do {
            theItems = try FileManager.default.contentsOfDirectory(atPath: (currPath?.path)!)
            return theItems
        } catch let error as NSError {
            print(error.localizedDescription)
            return theItems
        }
    }
    return theItems
}




