//
//  FolderDataCell.swift
//  Filemaneger_Demo
//
//  Created by SOTSYS032 on 06/06/18.
//  Copyright © 2018 SpaceoDigicom. All rights reserved.
//

import UIKit

class FolderDataCell: UITableViewCell {

    @IBOutlet weak var lblFileName: UILabel!
    @IBOutlet weak var imgviewFile: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
