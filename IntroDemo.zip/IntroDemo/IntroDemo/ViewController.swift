//
//  ViewController.swift
//  IntroDemo
//
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var introCollection: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    
    @IBOutlet weak var btnSkip: UIButton!
    
    
    let arrIntroImages = [#imageLiteral(resourceName: "sp1")]
    let arrtitle = ["Great stores. Great choices","Rediscover a great shopping tradition","Save money. Live better.","Shop for what you want."]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pageControl.numberOfPages = 4
        
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrtitle.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let aCell = collectionView.dequeueReusableCell(withReuseIdentifier: "introCollectionCell", for: indexPath) as! IntroCollectionCell
        aCell.imgView1.image = UIImage(named: "a\(indexPath.row + 1)")
        aCell.lblTitle1.text = arrtitle[indexPath.row]
        return aCell
        
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView.frame.size
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        pageControl.currentPage = Int(scrollView.contentOffset.x) / Int(scrollView.frame.width)
        var visibleRect = CGRect()
        visibleRect.origin = introCollection.contentOffset
        visibleRect.size = introCollection.bounds.size
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        guard let indexPath = introCollection.indexPathForItem(at: visiblePoint) else { return }
        print(indexPath)
        if indexPath.row == 3{
            btnSkip.setTitle("Get Started", for: .normal)
        }else{
             btnSkip.setTitle("Skip", for: .normal)
        }
        
    }
    
    @IBAction func btnActionDone(_ sender: UIButton) {
    }
    
    
}

