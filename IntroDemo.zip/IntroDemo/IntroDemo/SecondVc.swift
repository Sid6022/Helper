//
//  SecondVc.swift
//  IntroDemo
//
//  Copyright © 2018 mac. All rights reserved.
//

import UIKit

class SecondVc: UIViewController {
    
    @IBOutlet var skipButton: UIButton!
    
    fileprivate let items = [
        OnboardingItemInfo(informationImage: #imageLiteral(resourceName: "a1"),
                           title: "Sell More, Get More",
                           description: "Great stores. Great choices",
                           pageIcon: #imageLiteral(resourceName: "Key"),
                           color: UIColor(red: 0.40, green: 0.56, blue: 1.71, alpha: 1.00),
                           titleColor: UIColor.black, descriptionColor: UIColor.black, titleFont: UIFont.systemFont(ofSize: 18, weight: UIFont.Weight.light), descriptionFont: UIFont.systemFont(ofSize: 22, weight: UIFont.Weight.bold)),
        
        OnboardingItemInfo(informationImage: #imageLiteral(resourceName: "a4"),
                           title: "Sell More, Get More",
                           description: "Rediscover a great shopping tradition",
                           pageIcon: #imageLiteral(resourceName: "Key"),
                           color: UIColor.orange,
                           titleColor: UIColor.black, descriptionColor: UIColor.black, titleFont: UIFont.systemFont(ofSize: 18, weight: UIFont.Weight.light), descriptionFont: UIFont.systemFont(ofSize: 22, weight: UIFont.Weight.bold)),
        
        OnboardingItemInfo(informationImage: #imageLiteral(resourceName: "a2"),
                           title: "Sell More, Get More",
                           description: "Save money. Live better.",
                           pageIcon: #imageLiteral(resourceName: "Key"),
                           color: UIColor.magenta,
                           titleColor: UIColor.black, descriptionColor: UIColor.black, titleFont: UIFont.systemFont(ofSize: 18, weight: UIFont.Weight.light), descriptionFont: UIFont.systemFont(ofSize: 22, weight: UIFont.Weight.bold)),
        
        OnboardingItemInfo(informationImage: #imageLiteral(resourceName: "a4"),
                           title: "Sell More, Get More",
                           description: "Shop for what you want.",
                           pageIcon: #imageLiteral(resourceName: "Key"),
                           color: UIColor(red: 2.0, green: 0.56, blue: 0.74, alpha: 1.00),
                           titleColor: UIColor.black, descriptionColor: UIColor.black, titleFont: UIFont.systemFont(ofSize: 18, weight: UIFont.Weight.light), descriptionFont: UIFont.systemFont(ofSize: 22, weight: UIFont.Weight.bold)),
        
        ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        skipButton.isHidden = true
        setupPaperOnboardingView()
        view.bringSubview(toFront: skipButton)
    }
    
    private func setupPaperOnboardingView() {
        let onboarding = PaperOnboarding()
        onboarding.delegate = self
        onboarding.dataSource = self
        onboarding.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(onboarding)
        
        // Add constraints
        for attribute: NSLayoutAttribute in [.left, .right, .top, .bottom] {
            let constraint = NSLayoutConstraint(item: onboarding,
                                                attribute: attribute,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: attribute,
                                                multiplier: 1,
                                                constant: 0)
            view.addConstraint(constraint)
        }
    }
}

// MARK: Actions

extension SecondVc {
    
    @IBAction func skipButtonTapped(_: UIButton) {
        print(#function)
    }
}

// MARK: PaperOnboardingDelegate

extension SecondVc: PaperOnboardingDelegate {
    
    func onboardingWillTransitonToIndex(_ index: Int) {
        skipButton.isHidden = index == 3 ? false : true
    }
    
    func onboardingDidTransitonToIndex(_: Int) {
    }
    
    func onboardingConfigurationItem(_ item: OnboardingContentViewItem, index: Int) {
        //item.titleLabel?.backgroundColor = .redColor()
        //item.descriptionLabel?.backgroundColor = .redColor()
        //item.imageView = ...
    }
}

// MARK: PaperOnboardingDataSource

extension SecondVc: PaperOnboardingDataSource {
    
    func onboardingItem(at index: Int) -> OnboardingItemInfo {
        return items[index]
    }
    
    func onboardingItemsCount() -> Int {
        return 4
    }
    
    //    func onboardinPageItemRadius() -> CGFloat {
    //        return 2
    //    }
    //
    //    func onboardingPageItemSelectedRadius() -> CGFloat {
    //        return 10
    //    }
    //    func onboardingPageItemColor(at index: Int) -> UIColor {
    //        return [UIColor.white, UIColor.red, UIColor.green][index]
    //    }
}

