//
//  IntroCollectionCell.swift
//  IntroDemo
//
//  Copyright © 2018 mac. All rights reserved.
//

import UIKit

class IntroCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var imgView1: UIImageView!
    
    @IBOutlet weak var lblTitle1: UILabel!
    
    
    
}
