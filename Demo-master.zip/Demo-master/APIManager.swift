//
//  APIManager.swift
//  Version 1.0 - Swift 3.0

import UIKit
import MobileCoreServices
import Foundation

enum URLRequestType: String {
    case POST
    case GET
}

public typealias CompletionHandlerDownload = (Dictionary<String, Any>?, Error?) -> Void
public typealias DownloadProgress = (_ progress: Float) -> ()

class APIManager : NSObject {
    
    var localURL : URL?
    var successDownloadHandler: CompletionHandlerDownload?
    var progressDownloadHandler: DownloadProgress?
    
    //MARK: Calling API
    static func callAPI(_ apiURL: String, of type: URLRequestType, withParamaters paramaters: [String : Any], andHeaders headers: [String : String]? = nil, _ completion : @escaping (_ dictResponse: Dictionary<String, AnyObject>?, _ error: Error?) -> ()){
        switch type.rawValue {
        case "POST":
            if paramaters.values.contains(where: { (value) -> Bool in
                return value is Data
            }){
                postAPIWithImageUpload(apiURL, paramaters, headers, completion)
            }else{
                postAPIWithFormData(apiURL, paramaters, headers, completion)
            }
        case "GET":
            getWebService(apiURL, completionHandler: completion)
        default:
            break
        }
    }
   
    //MARK: Post API With Formdata
    static func postAPIWithFormData(_ apiURL: String, _ paramaters: [String : Any], _ headers: [String : String]? = nil, _ completion : @escaping (_ dictResponse: Dictionary<String, AnyObject>?, _ error: Error?) -> ()){
        let url = URL(string: apiURL.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlFragmentAllowed)!)
        var request = URLRequest(url: url!)
        request.httpMethod = URLRequestType.POST.rawValue
        request.cachePolicy = URLRequest.CachePolicy.reloadIgnoringLocalCacheData
        if let headers = headers{
            for value in headers.enumerated(){
                request.setValue(value.element.value, forHTTPHeaderField: value.element.key)
            }
        }
        var paramString = String()
        for (key, value) in paramaters {
            var newValue : Any?
            if let val = value as? String {
                newValue = val.replacingOccurrences(of: "+", with: "%2B")
            }else{
                newValue = value
            }
            paramString = paramString + (key) + "=" + "\(newValue!)" + "&"
        }
        paramString.characters.removeLast()
        request.httpBody = paramString.data(using: .utf8)
        
        let task = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
            DispatchQueue.main.async {
                do{
                    if let data = data{
                        let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? Dictionary<String, AnyObject>
                        if let parsedJSON = json {
                            //Parsed JSON
                            completion(parsedJSON, nil)
                        }else{
                            // Woa, okay the json object was nil, something went worng. Maybe the server isn't running?
                            let jsonStr = String(data: data, encoding: .utf8)
                            #if DEBUG
                                print("Error could not parse JSON: \(jsonStr ?? "")")
                            #endif
                        }
                    }else{
                        completion(nil, error)
                    }
                }catch let error{
                    completion(nil, error)
                }
            }
        })
        task.resume()
    }
    //MARK: POST API With Image Upload
    
    
    //MARK: Post API With Formdata
    
    static func postAPIWithImageUpload(_ apiURL: String, _ paramaters: [String : Any], _ headers: [String : String]? = nil, _ completion : @escaping (_ dictResponse: Dictionary<String, AnyObject>?, _ error: Error?) -> ()){
        let request = createRequest(apiURL, paramaters, headers)
        let task = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
            DispatchQueue.main.async {
                do{
                    if let data = data{
                        let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? Dictionary<String, AnyObject>
                        if let parsedJSON = json{
                            //Parsed JSON
                            completion(parsedJSON, nil)
                        }else{
                            // Woa, okay the json object was nil, something went worng. Maybe the server isn't running?
                            let jsonStr = String(data: data, encoding: .utf8)
                            #if DEBUG
                                print("Error could not parse JSON: \(jsonStr ?? "")")
                            #endif
                        }
                    }else{
                        completion(nil, error)
                    }
                }catch let error{
                    completion(nil, error)
                }
            }
        })
        task.resume()
    }
    
    fileprivate static func createRequest(_ apiURL: String, _ paramaters: [String : Any], _ headers: [String : String]? = nil) -> URLRequest{
        // build your dictionary however appropriate
        let boundary = generateBoundary()
        let url = URL(string: apiURL)
        var request = URLRequest(url: url!)
        request.httpMethod = URLRequestType.POST.rawValue
        request.timeoutInterval = 300
        if let headers = headers{
            for value in headers.enumerated(){
                request.setValue(value.element.value, forHTTPHeaderField: value.element.key)
            }
        }
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.httpBody = createBody(withParamaters: paramaters, boundary)
        return request
        
    }
    
    /// Create boundary string for multipart/form-data request
    ///
    /// - returns:            The boundary string that consists of "Boundary-" followed by a UUID string.
    
    fileprivate static func generateBoundary() -> String {
        return "Boundary-\(UUID().uuidString)"
    }
    
    /// Create body of the multipart/form-data request
    ///
    /// - parameter parameters:   The optional dictionary containing keys and values to be passed to web service
    /// - parameter filePathKey:  The optional field name to be used when uploading files. If you supply paths, you must supply filePathKey, too.
    /// - parameter paths:        The optional array of file paths of the files to be uploaded
    /// - parameter boundary:     The multipart/form-data boundary
    ///
    /// - returns:                The Data of the body of the request
    
    fileprivate static func createBody(withParamaters paramaters: [String : Any]? = nil, _ boundary: String) -> Data{
        var body = Data()
        if let paramaters = paramaters{
            for value in paramaters.enumerated(){
                
                if let imgData = value.element.value as? Data{
                    body.append("--\(boundary)\r\n".data(using: .utf8)!)
                    body.append("Content-Disposition: form-data; name=\"\(value.element.key)\"; filename=\"img.jpg\"\r\n".data(using: .utf8)!)
                    body.append("Content-Type: application/octet-stream\r\n\r\n".data(using: .utf8)!)
                    body.append(imgData)
                    body.append("\r\n".data(using: .utf8)!)
                }else{
                    body.append("--\(boundary)\r\n".data(using: .utf8)!)
                    body.append("Content-Disposition: form-data; name=\"\(value.element.key)\"\r\n\r\n".data(using: .utf8)!)
                    body.append("\(value.element.value)\r\n".data(using: .utf8)!)
                }
            }
        }
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        return body
    }
    
    //MARK: GET API
    static func getWebService(_ apiURL: String, completionHandler: @escaping (_ dictResponse: Dictionary<String, AnyObject>?, _ error: Error?) -> ()){
        var request = URLRequest(url: URL(string: apiURL)!)
        request.allHTTPHeaderFields = createHeaders()
        let getTask = URLSession.shared.dataTask(with: request) { (responseData, _, error) in
            DispatchQueue.main.async {
                do{
                    if responseData != nil{
                        let json = try JSONSerialization.jsonObject(with: responseData!, options: JSONSerialization.ReadingOptions.allowFragments) as? Dictionary<String, AnyObject>
                        if let parsedJSON = json{
                            //Json Parsed Successfully
                            completionHandler(parsedJSON, nil)
                        }else{
                            //Cannot parse json or data must be nil
                            let jsonStr = String(data: responseData!, encoding: String.Encoding.utf8)
                            #if DEBUG
                                print("Error could not parse JSON: \(jsonStr ?? "")")
                            #endif
                        }
                    }else{
                        completionHandler(nil, error)
                    }
                }catch let error{
                    print(error.localizedDescription)
                    completionHandler(nil, error)
                }
            }
        }
        getTask.resume()
    }

    func downloadFile(strUrl: String, to localUrl: URL) {
        
        localURL = localUrl
        
        let configuration = URLSessionConfiguration.background(withIdentifier: "bgSessionConfiguration")
        let session = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
        
        let url = URL(string: strUrl)!
        let urlRequest = URLRequest(url: url, cachePolicy: URLRequest.CachePolicy.reloadIgnoringLocalCacheData, timeoutInterval: 60.0)
        let currentTask = session.downloadTask(with: urlRequest)
        currentTask.resume()
        
    }
    
    static func createHeaders() -> [String : String]? {
        if let authKey = UserDefaults.standard.string(forKey: kCurrentAuthKey)
        {
            print("Auth key \(authKey)")
            return ["authKey" : authKey]
        } else {
            return nil
        }
    }
}

extension APIManager : URLSessionTaskDelegate, URLSessionDownloadDelegate {

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        do {
            try FileManager.default.copyItem(at: location, to: localURL!)
            let dict = ["localUrl" : localURL!]
            successDownloadHandler!(dict, nil)
        }catch{
            
        }
    }
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        print(downloadTask.taskIdentifier)
        let progress : Float = Float(totalBytesWritten) / Float(totalBytesExpectedToWrite)
        progressDownloadHandler!(progress)
    }
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didResumeAtOffset fileOffset: Int64, expectedTotalBytes: Int64) {

    }
    
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
       print(error?.localizedDescription ?? "Finish")
        if error ==  nil{

        }else{
            task.cancel()
            task.suspend()
            successDownloadHandler!(nil, error)
        }
       
    }
}
