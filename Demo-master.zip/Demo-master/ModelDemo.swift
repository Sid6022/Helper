//
//  ViewController.swift
//  iMusic_Demo
//
//  Created by SOTSYS032 on 04/05/18.
//  Copyright © 2018 SpaceoDigicom. All rights reserved.
//

import Foundation


class ModelDemo: NSObject,NSCoding {

    var strArtistName : String!
    var strTrackName  : String!
    var strPreviewUrl : String!
    var intTrackTime  : Int!
    var strThunbimg   : String!

    init(fromDict dict:[String : Any]) {
        strArtistName = dict["artistName"] as? String
        strTrackName = dict["trackName"] as? String
        strPreviewUrl = dict["previewUrl"] as? String
        intTrackTime = dict["trackTimeMillis"] as? Int
        strThunbimg = dict["artworkUrl100"] as? String
    }
    
    func toDict() -> [String : Any] {
        var dictData = [String:Any]()
        if strArtistName != nil{
            dictData["artistName"] = strArtistName
        }
        if strTrackName != nil{
            dictData["trackName"] = strTrackName
        }
        if strPreviewUrl != nil{
            dictData["previewUrl"] = strPreviewUrl
        }
        if intTrackTime != nil{
            dictData["trackTimeMillis"] = intTrackTime
        }
        if strThunbimg != nil{
            dictData["artworkUrl100"] = strThunbimg
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        strArtistName = aDecoder.decodeObject(forKey: "artistName") as? String
        strTrackName = aDecoder.decodeObject(forKey: "trackName") as? String
        strPreviewUrl = aDecoder.decodeObject(forKey: "previewUrl") as? String
        intTrackTime = aDecoder.decodeObject(forKey: "trackTimeMillis") as? Int
        strThunbimg = aDecoder.decodeObject(forKey: "artworkUrl100") as? String
    }
    
    func encode(with aCoder: NSCoder) {
        if strArtistName != nil{
            aCoder.encode(strTrackName, forKey: "artistName")
        }
        if strTrackName != nil{
            aCoder.encode(strTrackName, forKey: "trackName")
        }
        if strPreviewUrl != nil{
            aCoder.encode(strTrackName, forKey: "previewUrl")
        }
        if intTrackTime != nil{
            aCoder.encode(strTrackName, forKey: "trackTimeMillis")
        }
        if strThunbimg != nil{
            aCoder.encode(strTrackName, forKey: "artworkUrl100")
        }
    }
    
}
